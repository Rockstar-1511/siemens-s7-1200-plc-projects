# Project 4: Ignition SCADA Integration (S7-1200, Ignition SCADA)

## Objective
Connect the S7-1200 PLC to Ignition for supervisory monitoring and control.

## Features
- OPC/driver connection to the S7-1200 (TODO: state which driver you used)
- Tags for process inputs, outputs and status
- HMI screens for monitoring and control
- Alarms for fault conditions
- Trends for process variables

## Tag list (TODO: replace with your real tags)
| Ignition tag | PLC address | Direction | Description |
|--------------|-------------|-----------|-------------|
| Motor/Run_Status | %Q0.0 | Read | Motor running |
| Motor/Fault | %M0.0 | Read | Fault latched |
| Motor/Start_Cmd | %M10.0 | Write | Remote start |

## Alarms (TODO)
| Alarm | Condition | Priority |
|-------|-----------|----------|
| Motor overload | Fault = true | High |

## Screenshots
Add: Designer tag browser, each HMI screen, alarm journal, trend chart.

## Notes
Concepts applied: data acquisition, supervisory control, HMI, communications.

## Architecture / SLD
![PLC to Ignition architecture](sld/architecture.png)

## Screenshots
![Tag browser](screenshots/01-tag-browser.png)
![HMI overview screen](screenshots/02-hmi-overview.png)
![Alarm journal](screenshots/03-alarm-journal.png)
![Trend chart](screenshots/04-trends.png)
