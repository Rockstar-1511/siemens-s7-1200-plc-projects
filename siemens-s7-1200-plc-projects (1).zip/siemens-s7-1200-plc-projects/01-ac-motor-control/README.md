# Project 1: AC Motor Control (S7-1200, TIA Portal, Factory I/O, Simulated)

## Objective
Direct-on-line style motor control logic with start/stop, jog, protection and fault handling.

## Features
- Start/stop with **seal-in** (latching) circuit
- **Jog** (momentary run, bypasses seal-in)
- **Interlocks** preventing conflicting commands (e.g., jog and run at once)
- **Overload trip**: motor stops and fault latches
- **Fault latch/reset**: motor locked out until fault clears and reset is pressed

## I/O list (TODO: match to your actual tag table)
| Address | Tag | Type | Description |
|---------|-----|------|-------------|
| %I0.0 | PB_Start | DI | Start pushbutton (NO) |
| %I0.1 | PB_Stop | DI | Stop pushbutton (NC) |
| %I0.2 | PB_Jog | DI | Jog pushbutton (NO) |
| %I0.3 | OL_Contact | DI | Overload contact (NC) |
| %I0.4 | PB_Reset | DI | Fault reset (NO) |
| %Q0.0 | K1_Contactor | DO | Motor contactor coil |
| %Q0.1 | Lamp_Fault | DO | Fault indicator |
| %M0.0 | Fault_Latch | Memory | Latched fault bit |

## Logic summary
1. Run = (Start OR Run) AND Stop AND NOT Fault AND NOT Jog
2. Jog = Jog pushbutton AND NOT Fault AND NOT Run
3. K1 = Run OR Jog
4. Fault latches when overload opens; clears only when OL is healthy AND Reset pressed

## Test cases
| Scenario | Expected result | Pass |
|----------|-----------------|------|
| Start then stop | Motor runs, then stops | TODO |
| Jog held / released | Runs only while held | TODO |
| Start + jog together | Interlock blocks conflict | TODO |
| Overload during run | Motor trips, fault latches | TODO |
| Reset with fault active | Stays locked out | TODO |
| Reset after fault clears | Motor available again | TODO |

## Files
`tia-project/` TIA archive (.zap) | `screenshots/` ladder rungs and Factory I/O scene

## Single Line Diagram (SLD)
Upload your SLD to `sld/` and keep the filename below (or edit the path).

![Motor starter SLD](sld/motor-control-sld.png)

## Screenshots
Upload to `screenshots/` with these names (or edit the paths).

![Ladder logic](screenshots/01-ladder-logic.png)
![Tag table](screenshots/02-tag-table.png)
![Factory I/O scene](screenshots/03-factory-io-scene.png)
![Overload fault test](screenshots/04-overload-fault.png)
