# Project 2: PLC Box-Sorting Line (S7-1200, TIA Portal, Factory I/O, Simulated)

## Objective
Automate a conveyor line that detects boxes and routes them with a diverter.

## Features
- Box detection with photoelectric sensors
- Conveyor start/stop control
- Diverter actuation to route boxes to the correct path
- Step-based sequence with timers and sensor feedback
- Edge cases handled: missed detections, back-to-back boxes, jams

## I/O list (TODO: match to your actual tag table)
| Address | Tag | Type | Description |
|---------|-----|------|-------------|
| %I0.0 | Start / %I0.1 Stop | DI | Line control |
| %I0.2 | Sensor_Entry | DI | Box detected at entry |
| %I0.3 | Sensor_Divert | DI | Box at diverter |
| %Q0.0 | Conveyor | DO | Conveyor motor |
| %Q0.1 | Diverter | DO | Diverter actuator |

## Sequence
1. Idle: line stopped
2. Run: conveyor on
3. Box detected at entry: track box
4. Box reaches diverter sensor: fire diverter (timed pulse)
5. Diverter retracts after timer: return to Run
6. Jam timeout: stop conveyor, raise fault

## Test cases
| Scenario | Expected result | Pass |
|----------|-----------------|------|
| Single box | Routed correctly | TODO |
| Back-to-back boxes | Both routed, none missed | TODO |
| Missed detection | Handled without lockup | TODO |
| Jam | Timeout stops line, fault set | TODO |

## Files
`tia-project/` | `screenshots/` (ladder, Factory I/O scene, short recording if available)

## Single Line Diagram (SLD)
![Conveyor and diverter power SLD](sld/box-sorting-sld.png)

## Screenshots
![Ladder logic](screenshots/01-ladder-logic.png)
![Tag table](screenshots/02-tag-table.png)
![Factory I/O scene](screenshots/03-factory-io-scene.png)
![Diverter in action](screenshots/04-diverter-routing.png)
