# Project 3: PLC Paint-Production Process (S7-1200, TIA Portal, Factory I/O, Simulated)

## Objective
Batch process controlling inlet valves, mixing and pump operation in a defined order, with level protection.

## Features
- Batch sequencing: fill, mix, discharge
- Valve and pump control
- High/low level monitoring (overfill and dry-run protection)
- Timer-based mixing
- Start-up, running, fault and E-stop states; safe return to initial state

## I/O list (TODO: match to your actual tag table)
| Address | Tag | Type | Description |
|---------|-----|------|-------------|
| %I0.0 | Start / %I0.1 E_Stop | DI | Process control |
| %I0.2 | Level_Low | DI | Low level sensor |
| %I0.3 | Level_High | DI | High level sensor |
| %Q0.0 | Inlet_Valve_A / %Q0.1 Inlet_Valve_B | DO | Ingredient valves |
| %Q0.2 | Mixer | DO | Mixer motor |
| %Q0.3 | Outlet_Pump | DO | Discharge pump |

## Sequence
1. Idle
2. Fill A until level reaches setpoint
3. Fill B until high level
4. Mix for set time (timer)
5. Discharge via pump until low level
6. Return to Idle

Abnormal level or E-stop: valves closed, mixer and pump off, fault state.

## Test cases
| Scenario | Expected result | Pass |
|----------|-----------------|------|
| Normal batch | Full cycle completes | TODO |
| E-stop mid-batch | Outputs off, fault state | TODO |
| Pump with low level | Dry-run blocked | TODO |
| Fill past high level | Valve closes | TODO |

## Files
`tia-project/` | `screenshots/`

## Single Line Diagram (SLD) / P&ID
![Process SLD / P&ID](sld/paint-production-sld.png)

## Screenshots
![Ladder logic](screenshots/01-ladder-logic.png)
![Tag table](screenshots/02-tag-table.png)
![Factory I/O scene](screenshots/03-factory-io-scene.png)
![Batch cycle running](screenshots/04-batch-running.png)
